package app.androidhive.info.realm.core;

/**
 * Marker class for resuming a timer through Otto
 */
public class ResumeTimerEvent {
}
