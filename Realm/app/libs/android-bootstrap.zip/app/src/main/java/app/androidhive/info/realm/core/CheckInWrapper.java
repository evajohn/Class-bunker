package app.androidhive.info.realm.core;

import java.util.List;

public class CheckInWrapper {
    private List<CheckIn> results;

    public List<CheckIn> getResults() {
        return results;
    }
}
