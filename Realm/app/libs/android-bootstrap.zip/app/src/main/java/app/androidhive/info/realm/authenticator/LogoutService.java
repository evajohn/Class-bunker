package app.androidhive.info.realm.authenticator;

public interface LogoutService {
    void logout(Runnable onSuccess);
}
