package app.androidhive.info.realm.core;

/**
 * Marker class for Otto for a pause event for the timer.
 */
public class PauseTimerEvent {
}
