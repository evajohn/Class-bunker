package app.androidhive.info.realm.core;


import java.util.List;

public class NewsWrapper {
    private List<News> results;

    public List<News> getResults() {
        return results;
    }
}
