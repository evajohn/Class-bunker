package app.androidhive.info.realm.core;

public class IntentFactory {
    //TODO implement an Activity and Fragment delegate pattern
}
